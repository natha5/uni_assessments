//major code source: https://www.w3schools.com/howto/howto_js_slideshow.asp

var mainImageIndex = 0;
var images = document.getElementsByClassName("galleryImage");

window.onload = function(){
    showMainImage(mainImageIndex);
}

function changeImages(n){
    mainImageIndex += n
    showMainImage(mainImageIndex)
}

function showMainImage(n){ 

    if (n > images.length - 1){
        mainImageIndex = 0;
    }

    if (n < 0){
        mainImageIndex = images.length - 1;
    }

    for (var i = 0; i < images.length; i++){
        images[i].classList.remove("mainImage");
        images[i].classList.remove("secondaryImage");
        images[i].classList.remove("leftImage");
        images[i].classList.remove("rightImage");
    }

    images[mainImageIndex].classList.add("mainImage");
    showSecondaryImage(mainImageIndex - 1, "leftImage");
    showSecondaryImage(mainImageIndex + 1, "rightImage");
}

function showSecondaryImage(n, left_right_class){
    var secondaryImageIndex = n;

    if (secondaryImageIndex > images.length - 1){
       secondaryImageIndex = 0;
    }

    if (secondaryImageIndex < 0){
        secondaryImageIndex = images.length - 1;
    }

    images[secondaryImageIndex].classList.add("secondaryImage");
    images[secondaryImageIndex].classList.add(left_right_class);
}