//https://www.w3schools.com/howto/howto_js_rangeslider.asp

var containers = document.getElementsByClassName("construction-image-container");
var slider; 

window.onload = function(){
    slider = document.getElementById("construction-slider");
    slider.value = 1;

    containers[0].classList.remove("disappear");
}

function ChangeImage(){
    var currentValue = slider.value;
    for (var i = 0; i < containers.length; i++){
        if (i == currentValue - 1){
            containers[i].classList.remove("disappear");
        }
        else{
            containers[i].classList.add("disappear");
        }
    }
}


